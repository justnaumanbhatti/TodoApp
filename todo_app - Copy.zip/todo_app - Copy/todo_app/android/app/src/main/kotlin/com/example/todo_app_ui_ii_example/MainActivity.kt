package com.example.todo_app_ui_ii_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
